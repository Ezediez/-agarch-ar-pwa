-- TEST SIMPLE: Ver buckets de storage
SELECT name, public FROM storage.buckets;
