-- TEST: Verificar que la API Key sea correcta
-- Ve a tu proyecto Supabase → Settings → API
-- Verifica que estos valores coincidan:

-- 1) Project URL debe ser:
-- https://ygkhhpxejrajyeshwief.supabase.co

-- 2) anon public key debe empezar con:
-- eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSI...

-- Si no coinciden, copia los valores correctos de Supabase
