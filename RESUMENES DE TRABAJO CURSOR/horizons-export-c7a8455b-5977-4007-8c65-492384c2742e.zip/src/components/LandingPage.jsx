import React from 'react';

const LandingPage = () => {
  // This component is not being used, its content was moved to pages/LandingPage.jsx
  // It is kept to avoid breaking imports but can be removed if not referenced anywhere else.
  return null;
};

export default LandingPage;