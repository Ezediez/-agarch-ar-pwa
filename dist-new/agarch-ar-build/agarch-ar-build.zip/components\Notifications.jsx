import React from 'react';
import NotificationBell from '@/components/notifications/NotificationBell';

const Notifications = () => {
  return <NotificationBell />;
};

export default Notifications;
